#ifndef CADIO_RX
#define CADIO_RX 99
#endif

#ifndef CADIO_TX
#define CADIO_TX 99
#endif

#ifndef CadioSerial_h
#define CadioSerial_h

#include "cadioSoftwareSerial.h"

String CadioMidString(String str, String start, String finish) {
  int locStart = str.indexOf(start);
  if (locStart == -1) return "";
  locStart += start.length();
  int locFinish = str.indexOf(finish, locStart);
  if (locFinish == -1) return "";
  return str.substring(locStart, locFinish);
}

class CadioSerial {
  public:
    CadioSerial();
    typedef void (*ordcbfunc_t) (int index, int value);
    typedef void (*fancbfunc_t) (int value);
    typedef void (*stampcbfunc_t) (unsigned long value);
    typedef void (*donecbfunc_t) ();
    void begin();
    void onOrder(ordcbfunc_t cadioOrderCallback_new);
    void onDone(donecbfunc_t cadioDoneCallback_new);
    void onSwitchOrder(ordcbfunc_t cadioSwitchOrderCallback_new);
    void onSwitchStatus(ordcbfunc_t cadioSwitchStatusCallback_new);
    void onFanOrder(fancbfunc_t cadioFanOrderCallback_new);
    void onTimestamp(stampcbfunc_t cadioStampCallback_new);
    void loop();
    void forwardOrder();
    void forwardSwitchOrder(int index, int value);
    void forwardTimestamp(unsigned long value);
    void forwardSwitchStatus(int index, int value);
    void set(int index, int value);
    void set(int index, String value);
    void sendNotification(String value);
    void getCurrentStatus();
    void getCurrentTime();
    void process(String msg);
  private:
    String cadioReceivedMsg = "";
    bool normalSerial = false;

    ordcbfunc_t cadioOrderCallback;
    donecbfunc_t cadioDoneCallback;
    ordcbfunc_t cadioSwitchOrderCallback;
    ordcbfunc_t cadioSwitchStatusCallback;
    fancbfunc_t cadioFanOrderCallback;
    stampcbfunc_t cadioStampCallback;

    bool cadioOrderCallback_active = false;
    bool cadioDoneCallback_active = false;
    bool cadioSwitchOrderCallback_active = false;
    bool cadioSwitchStatusCallback_active = false;
    bool cadioFanOrderCallback_active = false;
    bool cadioStampCallback_active = false;
};

SoftwareSerial cadioSoftSerial(CADIO_RX, CADIO_TX);

CadioSerial::CadioSerial(){
  if(CADIO_RX == 99 || CADIO_TX == 99){
    normalSerial = true;
  }
}

void CadioSerial::begin(){
  if(normalSerial){
    Serial.begin(9600);
  }else{
    cadioSoftSerial.begin(9600);
  }
}

void CadioSerial::onOrder(ordcbfunc_t cadioOrderCallback_new){
  cadioOrderCallback_active = true;
  cadioOrderCallback = cadioOrderCallback_new;
}

void CadioSerial::onDone(donecbfunc_t cadioDoneCallback_new){
  cadioDoneCallback_active = true;
  cadioDoneCallback = cadioDoneCallback_new;
}

void CadioSerial::onSwitchOrder(ordcbfunc_t cadioSwitchOrderCallback_new){
  cadioSwitchOrderCallback_active = true;
  cadioSwitchOrderCallback = cadioSwitchOrderCallback_new;
}

void CadioSerial::onSwitchStatus(ordcbfunc_t cadioSwitchStatusCallback_new){
  cadioSwitchStatusCallback_active = true;
  cadioSwitchStatusCallback = cadioSwitchStatusCallback_new;
}

void CadioSerial::onFanOrder(fancbfunc_t cadioFanOrderCallback_new){
  cadioFanOrderCallback_active = true;
  cadioFanOrderCallback = cadioFanOrderCallback_new;
}

void CadioSerial::onTimestamp(stampcbfunc_t cadioStampCallback_new){
  cadioStampCallback_active = true;
  cadioStampCallback = cadioStampCallback_new;
}

void CadioSerial::forwardOrder(){
  if(normalSerial){
    Serial.println(cadioReceivedMsg);
  }else{
    cadioSoftSerial.println(cadioReceivedMsg);
  }
}

void CadioSerial::forwardSwitchOrder(int index, int value){
  String switchOrder = "(" + String(index) + "X" + String(value) + ")";
  if(normalSerial){
    Serial.println(switchOrder);
  }else{
    cadioSoftSerial.println(switchOrder);
  }
}

void CadioSerial::forwardSwitchStatus(int index, int value){
  String switchStatus = "(" + String(index) + "S" + String(value) + ")";
  if(normalSerial){
    Serial.println(switchStatus);
  }else{
    cadioSoftSerial.println(switchStatus);
  }
}

void CadioSerial::forwardTimestamp(unsigned long value){
  String timestampOrder = "(37:" + String(value) + ")";
  if(normalSerial){
    Serial.println(timestampOrder);
  }else{
    cadioSoftSerial.println(timestampOrder);
  }
}

void CadioSerial::set(int index, int value) {
  String msgToSend = "[" + String(index) + ":" + String(value) + "]";
  if(normalSerial){
    Serial.println(msgToSend);
  }else{
    cadioSoftSerial.println(msgToSend);
  }
}

void CadioSerial::set(int index, String value) {
  String msgToSend = "[" + String(index) + ":" + String(value) + "]";
  if(normalSerial){
    Serial.println(msgToSend);
  }else{
    cadioSoftSerial.println(msgToSend);
  }
}

void CadioSerial::getCurrentStatus() {
  String msgToSend = "[get]";
  if(normalSerial){
    Serial.println(msgToSend);
  }else{
    cadioSoftSerial.println(msgToSend);
  }
}

void CadioSerial::getCurrentTime() {
  String msgToSend = "[time]";
  if(normalSerial){
    Serial.println(msgToSend);
  }else{
    cadioSoftSerial.println(msgToSend);
  }
}

void CadioSerial::sendNotification(String value){
  String msgToSend = "[noti:" + value + "]";
  if(normalSerial){
    Serial.println(msgToSend);
  }else{
    cadioSoftSerial.println(msgToSend);
  }
}

void CadioSerial::process(String msg) {
  String myMsg = CadioMidString(msg, "(", ")");
  int th0 = myMsg.indexOf(':');
  int th1 = myMsg.indexOf('X');
  int th2 = myMsg.indexOf('S');
  if(myMsg == "done"){
    if(cadioDoneCallback_active){
      cadioDoneCallback();
    }
  }else if(th0 > 0){
    int index = myMsg.substring(0, th0).toInt();
    int value = myMsg.substring(th0 + 1).toInt();
    if(index <= 21){
      if(cadioOrderCallback_active){
        cadioOrderCallback(index, value);
      }
    }else if(index == 35){
      if(cadioFanOrderCallback_active){
        cadioFanOrderCallback(value);
      }
    }else if(index == 37){
      if(cadioStampCallback_active){
        unsigned long stamp = myMsg.substring(th0 + 1).toInt();
        cadioStampCallback(stamp);
      }
    }
  }else if(th1 > 0){
    int index = myMsg.substring(0, th1).toInt();
    int value = myMsg.substring(th1 + 1).toInt();
    if(cadioSwitchOrderCallback_active){
      cadioSwitchOrderCallback(index, value);
    }
  }else if(th2 > 0){
    int index = myMsg.substring(0, th2).toInt();
    int value = myMsg.substring(th2 + 1).toInt();
    if(cadioSwitchStatusCallback_active){
      cadioSwitchStatusCallback(index, value);
    }
  }
}

void CadioSerial::loop(){
  if(normalSerial){
    while (Serial.available() > 0 ) {
      char rc = Serial.read(); 
      if (rc == '(') {
        cadioReceivedMsg = "(";
      } else if (rc == ')') {
        cadioReceivedMsg += ")";
        this->process(cadioReceivedMsg);
        cadioReceivedMsg = "";
      } else {
        cadioReceivedMsg += rc;
      }
    }
  }else{
    while (cadioSoftSerial.available() > 0 ) {
      char rc = cadioSoftSerial.read();
      if (rc == '(') {
        cadioReceivedMsg = "(";
      } else if (rc == ')') {
        cadioReceivedMsg += ")";
        this->process(cadioReceivedMsg);
        cadioReceivedMsg = "";
      } else {
        cadioReceivedMsg += rc;
      }
    }
  }
  cadioReceivedMsg.trim();
}

#endif